var express = require('express');
//const app = express();
//const mysql = require('mysql');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');


var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users'); // routes for communityPage
var databaseRouter = require('./routes/dbtest');

var app = express();

app.use((req, resp, next) => {
    console.info('\x1b[42m\x1b[30m Request URL : ' + req.url + '\x1b[0m');
    next();
});

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({extended: false}));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));


app.use('/', indexRouter);
app.use('/dbtest', databaseRouter);
app.use('/users', usersRouter); //communityPage
module.exports = app;

app.get("/", function(req, res){
    res.send("Welcome to database");
});

const server = app.listen(3306, function(){
    console.log("connected to port 3306");
});
