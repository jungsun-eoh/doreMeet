const  mysql = require('mysql');

const pool = mysql.createPool({
    host: "127.0.0.1",
    user: "root",
    password: "1234",
    database: "mydb",
    connectionLimit: 50,
     insecureAuth: true,
     queueLimit: 0   
});

pool.query(`SELECT * FROM user`, (err, result, fields) =>{
    if(err){
        return console.log(err);
    }
    return console.log(result);
});

// connection.connect(function(err){
//     if(err)
//     throw err;
//     console.log("connected to database");
// });

// module.exports = connection;

//  connection from g
//  connection.connect(function(err){
//      if(!err){
//          console.log("Database is connected");
//      }else{
//          console.log("Error while connecting with database");
//      }
//  });

//const promisePool = pool.promise();
module.exports = pool;