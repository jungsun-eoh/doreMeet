var express = require('express');
var router = express.Router();
var db = require('../conf/database');

//import {Router} from express;

router.get('/getAllUsers', (req, res, next) => {
    res.send('testing 1, 2, 3, ...');
});

// "test": "echo \"Error: no test specified\" && exit 1"

module.exports = router;