var express = require('express');
var router = express.Router();


router.get('/', function(req, res, next){
res.sendFile('index.html'); // import index.html file here
});

module.exports = router;